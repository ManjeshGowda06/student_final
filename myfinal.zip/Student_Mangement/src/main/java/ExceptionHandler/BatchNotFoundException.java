package ExceptionHandler;

public class BatchNotFoundException extends RuntimeException{

	public BatchNotFoundException(String message) {
		super(message);
	}

}
