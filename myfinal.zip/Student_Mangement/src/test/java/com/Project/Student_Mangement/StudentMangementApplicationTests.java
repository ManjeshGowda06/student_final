package com.Project.Student_Mangement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentMangementApplicationTests {

	@Test
	void contextLoads() {
	}

}
